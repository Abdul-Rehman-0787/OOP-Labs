#include<iostream>        //l230787
using namespace std;

class File
{
public:
	File() {
		Filename = "\0";
		size = "\0";
		filetype = "\0";
	}
	File(string n,string s,string t) {
		Filename = n;
		size = s;
		filetype = t;
	}
	void open() {
		cout << "\n=============== File Opened ==================\n";
	}
	void close() {
		cout << "\n=============== File Closed ==================\n";
	}
	void displayinfo() {
		cout << "\n\t\t\tInfo of File\n";
		cout << "\nFile Name : \t" << Filename;
		cout << "\nFile Size : \t" << size;
		cout << "\nFile Type : \t" << filetype;
	}
	~File() {

	}

private:
	string Filename, size, filetype;
};

class Textfile : public File
{
public:
	Textfile() {
		numlines = 0;
	}
	Textfile(int num,string n, string s, string t):File(n,s,t) {
		numlines = num;
	}
	void open() {
		cout << "\n=============== File Opened ==================\n";
	}
	void close() {
		cout << "\n=============== File Closed ==================\n";
	}
	void displayinfor() {
		displayinfo();
		cout << "\nNumber of Lines : \t" << numlines;
	}
	~Textfile() {

	}

private:
	int numlines;//number of lines
};

class ImageFile : public File
{
public:
	ImageFile(){
		resolution = "\0";
	}
	ImageFile(string r, string n, string s, string t) :File(n, s, t) {
		resolution = r;
	}
	void open() {
		cout << "\n=============== File Opened ==================\n";
	}
	void close() {
		cout << "\n=============== File Closed ==================\n";
	}
	void displayinfor() {
		displayinfo();
		cout << "\nResolution of Image : \t" << resolution;
	}
	~ImageFile() {

	}

private:
	string resolution;
};

class VedioFile : public File
{
public:
	VedioFile() {
		durationinminutes = 0;
	}
	VedioFile(int d, string n, string s, string t) :File(n, s, t) {
		durationinminutes = 0;
	}
	void open() {
		cout << "\n=============== File Opened ==================\n";
	}
	void close() {
		cout << "\n=============== File Closed ==================\n";
	}
	void displayinfor() {
		displayinfo();
		cout << "\nTime : \t" << durationinminutes << "min. \n";
	}
	~VedioFile() {

	}

private:
	int durationinminutes;
};

class Folder
{
public:
	Folder() {
		size = 0;
	}
	Folder(File *p1) {
		p[size] = *p1;
		size++;
	}
	void addpointer(File* p1) {
		p[size] = *p1;
		size++;
	}
	void displayallfiles() {
		
		for (int i = 0; i < size; i++)
		{
			cout << "\n\t\t\t\tFile(i)\n";
			p[i].displayinfo();
		}
	}
	~Folder() {

	}

private:
	File p[10];  //Aggrigration (p is a pointer pointing on array of Files in Static Memmory)
	int size;
};

int main() {
	ImageFile Im("720*1080","Pic","6.2 mb","Image");
	Im.displayinfor();
	File p2("My_vedio","24 mb","Vedio");
	Folder F1(&p2);
	
	F1.displayallfiles();
}
