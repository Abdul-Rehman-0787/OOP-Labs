#include <iostream>                                                  //L23-0787  ABDUL-REHMAN NASEER

using namespace std;

class StringHolder {
private:
    char* string_ptr;

public:
    StringHolder(const char* str) {
        string_ptr = new char[strlength(str) + 1];
        strcopy(string_ptr, str);
    }

    StringHolder(const StringHolder& other) {
        string_ptr = new char[strlength(other.string_ptr) + 1];
        strcopy(string_ptr, other.string_ptr);
    }

    StringHolder(const StringHolder& other, bool shallowCopy) {
        string_ptr = nullptr;
        if (shallowCopy) {
            string_ptr = other.string_ptr;
        }
        else {
            string_ptr = new char[strlength(other.string_ptr) + 1];
            strcopy(string_ptr, other.string_ptr);
        }
    }

    

    StringHolder& operator=(const StringHolder& other) {
        if (this == &other)
            return *this;
        delete[] string_ptr;
        string_ptr = new char[strlength(other.string_ptr) + 1];
        strcopy(string_ptr, other.string_ptr);
        return *this;
    }

    void setString(const char* str) {
        delete[] string_ptr;
        string_ptr = new char[strlength(str) + 1];
        strcopy(string_ptr, str);
    }

    void display() const {
        cout << string_ptr << endl;
    }

    void strcopy(char* arr1, char const* arr2) {
        int size = 0;
        while (arr2[size] != '\0') {
            arr1[size] = arr2[size];
            size++;
        }
        arr1[size] = '\0';
    }

    int strlength(char const* str) {
        int size = 0;
        while (str[size] != '\0') {
            size++;
        }
        return size;
    }

    ~StringHolder() {
        delete[] string_ptr;
    }
};

int main() {
    StringHolder obj1("Hello World");
    StringHolder obj2 = obj1;
    obj2.setString("Deep Copy Example");
    cout << "Deep Copy : \t";
    obj1.display();
    obj2.display();
    cout << "\n\nShallow Copy : \t";
    StringHolder obj4("Shallow Copy Example");
    StringHolder obj3(obj4, true);
    obj4.display();
    obj3.display();
    return 0;
}
