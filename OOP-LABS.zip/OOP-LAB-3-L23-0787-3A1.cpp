#include <iostream>
//L23-0787         ABDUL-REHMAN NASEER
using namespace  std;

                         //Classes
class StringHolder {
private:
	char* str;
public:
	int Length;

	StringHolder(string strr) {
		int k = 0;
		while (strr[k] != '\0') {
			k++;
		}
		Length = k + 1;
		str = new char[Length];
		for (int i = 0; i < Length - 1; i++) {
			str[i] = strr[i];
		}
		str[Length - 1] = '\0';
	}

	void Displaystr() {
		cout << "\nLength of String : \t" << Length;
		int i = 0;
		cout << "\nYour String Array is : \t";
		while (str[i] != '\0') {
			cout << str[i];
			i++;
		}
	}

	~StringHolder() {
		delete[] str;
		str = nullptr;
	}
};

class Student {
private:
	int StudentId;
	string name;
	char grade;
	float GPA;

public:
	Student(int id, string n, char g, float gpa) {
		StudentId = id;
		name = n;
		grade = g;
		GPA = gpa;
	}

	int getStudentId() {
		return StudentId;
	}

	void setStudentId(int id) {
		StudentId = id;
	}

	string getName() {
		return name;
	}

	void setName(string na) {
		name = na;
	}

	char getGrade() {
		return grade;
	}

	void setGrade(char gr) {
		grade = gr;
	}

	float getGPA() {
		return GPA;
	}

	void setGPA(float gpa) {
		GPA = gpa;
	}

	void display() {
		cout << "Student ID: " << StudentId << endl;
		cout << "Name: " << name << endl;
		cout << "Grade: " << grade << endl;
		cout << "GPA: " << GPA << endl;
	}
};

class Product {
private:
	int Productid;
	string Productname;
	float price;
public:
	Product() {
		Productid = 0;
		Productname = "Empty";
		price = 0;
	}
	void setProductid(int id) {
		Productid = id;
	}
	void setProductname(string name) {
		Productname = name;
	}
	void setPrice(float pri) {
		price = pri;
	}

	void copyDetails(Product obj) {
		Productid = obj.Productid;
		Productname = obj.Productname;
		price = obj.price;
	}

	int getProductid() {
		return Productid;
	}

	string getProductname() {
		return Productname;
	}

	float getPrice() {
		return price;
	}
};


class BankAccount
{
private:
	int accountNumber;
	string	accountHolderName;
	double	balance;
public:
	BankAccount() {
		accountNumber = 0;
		accountHolderName = "Empty";
		balance = 0;
	}
	BankAccount(int num, string name, double bal) {
		accountNumber = num;
		accountHolderName = name;
		balance = bal;
	}
	void deposit(int amount) {
		balance = balance + amount;
	}
	void withdraw(int amount) {
		if (amount >= balance)
		{
			cout << "\nLow Balance !!!!!! \n";
		}
		else
		{
			balance = (balance - amount);
		}

	}
	void DisplayAccountInfo() {
		cout << "\nAccount Number : \t" << accountNumber;
		cout << "\nAccount Name   : \t" << accountHolderName;
		cout << "\nAccount Name   : \t$" << balance;
		cout << endl;
	}


};


//Declairing Functions
void printmanue();


int main() {
A: {
	printmanue();
	int Uchiha;       //signature
	cout << "\t\t\t\t1) Exercise-1\n";
	cout << "\t\t\t\t2) Exercise-2\n";
	cout << "\t\t\t\t3) Exercise-3\n";
	cout << "\t\t\t\t4) Exercise-4\n";
	cout << "\nPlease Enter the Code Number to Run the Program  : \t";
	cin >> Uchiha;

	if (Uchiha == 1)
	{
		printmanue();
		cout << "\t\t\t\t1) Exercise-1\n";
		string str;
		cout << "Enter Your String : \t";
		cin >> str;
		StringHolder Obj(str);
		Obj.Displaystr();
		
		
		
	}
	else if (Uchiha == 2)
	{
		printmanue();
		cout << "\t\t\t\t1) Exercise-2\n";
		Student Obj1(101, "John Doe", 'A', 3.75);
		Obj1.display();

		Obj1.setGrade('B');
		Obj1.setGPA(3.5);

		cout << "Updated Details:" << endl;
		cout << "Grade: " << Obj1.getGrade() << endl;
		cout << "GPA: " << Obj1.getGPA() << endl;

	}
	else if (Uchiha == 3)
	{
		printmanue();
		cout << "\t\t\t\t3) Exercise-3\n";

		Product Obj1;
		Obj1.setProductid(1001);
		Obj1.setProductname("Laptop");
		Obj1.setPrice(202.9);
		cout << "\nOriginal Product : \n";
		cout << "\nProduct Id    : \t" << Obj1.getProductid();
		cout << "\nProduct Name  : \t" << Obj1.getProductname();
		cout << "\nProduct Price : \t$" << Obj1.getPrice();
		Product Obj2;
		Obj2.copyDetails(Obj1);
		cout << "\nCopy Product : \n";
		cout << "\nProduct Id    : \t" << Obj2.getProductid();
		cout << "\nProduct Name  : \t" << Obj2.getProductname();
		cout << "\nProduct Price : \t$" << Obj2.getPrice();

	}
	else if (Uchiha == 4)
	{
		printmanue();
		cout << "\t\t\t\t3) Exercise-4\n";
		BankAccount Obj1;
		BankAccount Obj2(12345, "John Doe", 1000);
		Obj1.deposit(500);
		Obj2.withdraw(200);
		Obj2.deposit(1000);
		cout << "\nAccount 1 : \n";
		Obj1.DisplayAccountInfo();
		cout << "\nAccount 2 : \n";
		Obj2.DisplayAccountInfo();

	}
	else
	{
		cout << "\x1b[32m" << "\nPlease Enter the Right Choice!\n" << "\x1b[37m";
		goto A;
	}

	int RR;
	cout << "\x1b[34m" << "Please Enter 1 if you want to Re-Run the Program : \t";
	cin >> RR;
	cout << "\x1b[37m";
	if (RR == 1)
	{
		goto A;
	}
	else {
		return 0;
	}
	return 0;
	}
}






//Functions

void printmanue() {
	system("cls");
	cout << "\x1b[33m";
	cout << "\t\t\t\t======================\n";
	cout << "\t\t\t\t=  OOP LAB-BCS-3A1   =\n";
	cout << "\t\t\t\t=     LABWORK-3      =\n";
	cout << "\t\t\t\t=     L23 -0787      =\n";
	cout << "\t\t\t\t======================\n";
	cout << "=====================================================================================================\n";
	cout << "\x1b[37m";
}