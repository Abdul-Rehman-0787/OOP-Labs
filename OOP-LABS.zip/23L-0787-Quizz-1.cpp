#include <iostream>
using namespace std;

class Product
{
private:
	int ID;
	char* name;
	int quantity;
	int price;

public:
	Product() {
		ID = 0;
		name = nullptr;
		quantity = 0;
		price = 0;
	}

	Product(int id, string n, int q, int p) {
		ID = id;
		int length = 0;
		while (n[length] != '\0') {
			length++;
		}
		name = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			name[i] = n[i];
		}
		quantity = q;
		price = p;

	}
	Product(Product& Obj1) {
		ID = Obj1.ID;
		int length = 0;
		while (Obj1.name[length] != '\0') {
			length++;
		}
		name = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			name[i] = Obj1.name[i];
		}
		quantity = Obj1.quantity;
		price = Obj1.price;

	}
	void updateID(int i) {
		ID = i;
	}
	void updatequantity(int q) {
		quantity = q;
	}
	void updateprice(int p) {
		price = p;
	}
	void updatename(string n) {
		int length = 0;
		while (n[length] != '\0') {
			length++;
		}
		name = new char[length + 1];
		for (int i = 0; i < length; i++)
		{
			name[i] = n[i];
		}
	}
	void display() const {
		cout << "Product Id : \t" << ID << endl;
		cout << "Product Name : \t";
		int length = 0;
		while (name[length] != '\0') {
			length++;
		}
		for (int i = 0; i < length; i++)
		{
			cout << name[i];
		}
		cout << endl;
		cout << "Product Quantity : \t" << quantity << endl;
		cout << "Product Price : \t" << price << endl;
	}
	int totalvalue() {
		return (price * quantity);
	}
	~Product() {
		delete[] name;
	}

};




int main() {
	cout << "Please Enter the Number of Products : \t";
	int num;
	cin >> num;
	Product* arr = new Product[num];
	for (int i = 0; i < num; i++)
	{
		cout << "Product [" << i << "] : \n";
		int n;
		cout << "Enter the Product Id :\t";
		cin >> n;
		arr[i].updateID(n);
		string na;
		cout << "Enter the Product Name :\t";
		cin >> na;
		arr[i].updatename(na);
		int q;
		cout << "Enter the Product Quantity :\t";
		cin >> q;
		arr[i].updatequantity(q);
		int p;
		cout << "Enter the Product Price :\t";
		cin >> p;
		arr[i].updateprice(p);
	}
	cout << "Dispaly Objects : \n";
	for (int i = 0; i < num; i++)
	{
		cout << "Product [" << i << "] : \n";
		arr[i].display();
		cout << "Total inventry : \t" << arr[i].totalvalue();
		cout << endl;
	}
	int Uchiha = 1;
	while (Uchiha==1)
	{
		int i;
		cout << "Enter the Product number if you want to update any of them : \t";
		cin >> i;
		cout << "Product [" << i << "] : \n";
		int n;
		cout << "Enter the Product Id :\t";
		cin >> n;
		arr[i].updateID(n);
		string na;
		cout << "Enter the Product Name :\t";
		cin >> na;
		arr[i].updatename(na);
		int q;
		cout << "Enter the Product Quantity :\t";
		cin >> q;
		arr[i].updatequantity(q);
		int p;
		cout << "Enter the Product Price :\t";
		cin >> p;
		arr[i].updateprice(p);

		arr[i].display();
		cout << "Enter 1 for re run.\n";
			cin >> Uchiha;
	}
	
	return 0;
}