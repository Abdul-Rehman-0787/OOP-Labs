#include<iostream>             //23L-0787 Abdul-Rehman Naseer
using namespace std;

class Character
{
public:
	Character(string t) {
		type = t;
	}
	virtual void display() = 0;
	string getType() {
		return type;
	}
	virtual ~Character() {

	}

private:
	string type;
};
class HumanCharacter : public Character 
{
public:
	HumanCharacter(string n,string g,float p):Character("Human-Character") {
		name = n;
		gender = g;
		powerlevel = p;
	}
	void display() {
		cout << "\nType       : \t" << getType();
		cout << "\nName       : \t" << name;
		cout << "\nGender     : \t" << gender;
		cout << "\nPower      : \t" << powerlevel;
	}
	~HumanCharacter() {

	}

private:
	string name;
	string gender;
	float powerlevel;
};
class ElfCharacter : public Character
{
public:
	ElfCharacter(string n, string g, string tt) :Character("Elf-Character") {
		name = n;
		gender = g;
		Magictype = tt;
	}
	~ElfCharacter() {

	}
	void display() {

		cout << "\nType       : \t" << getType();
		cout << "\nName       : \t" << name;
		cout << "\nGender     : \t" << gender;
		cout << "\nMagic Type : \t" << Magictype;
	}
private:
	string name;
	string gender;
	string Magictype;
};

class Weapon
{
public:
	Weapon(string t) {
		typee = t;
	}
	virtual void display() = 0;
	string getType() {
		return typee;
	}
	virtual ~Weapon() {

	}

private:
	string typee;
};
class HumanWeapon :public Weapon
{
public:
	HumanWeapon() :Weapon("Human-Weapon") {
		Name = "\0";
		FightingStyle = "\0";
	}
	HumanWeapon(string n, string s) :Weapon("Human-Weapon") {
		Name = n;
		FightingStyle = s;
	}
	void display() {
		cout << "\n\nWeapon : \t";
		cout << "\nType           : \t" << getType();
		cout << "\nName           : \t" << Name;
		cout << "\nFighting Style : \t" << FightingStyle;
	}
	void method() {
		cout << "\n\t\t\tClose-Combat & Long Range Fight.\n";
	}
	void setweapon() {
		cout << "Enter the Name of Weapon : \t";
		cin >> Name;
		cout << "Enter the Fighting-Style of Weapon : \t";
		cin >> FightingStyle;

	}
	~HumanWeapon() {

	}

private:
	string Name;
	string FightingStyle;
};

class ElfWeapon :public Weapon
{
public:
	ElfWeapon() :Weapon("Elf-Weapon") {
		Name = "\0";
		FightingStyle = "\0";
	}
	ElfWeapon(string n,string s) :Weapon("Elf-Weapon") {
		Name = n;
		FightingStyle = s;
	}
	void display() {
		cout << "\n\nWeapon : \t";
		cout << "\nType           : \t" << getType();
		cout << "\nName           : \t" << Name;
		cout << "\nFighting Style : \t" << FightingStyle;
	}
	void method() {
		cout << "\n\t\t\tMagic.\n";
	}
	~ElfWeapon() {

	}
	void setweapon() {
		cout << "Enter the Name of Weapon : \t";
		cin >> Name;
		cout << "Enter the Fighting-Style of Weapon : \t";
		cin >> FightingStyle;

	}
private:
	string Name;
	string FightingStyle;
};
class Warrior : public HumanCharacter
{
public:
	Warrior(string e, float s, string n, string g, float p):HumanCharacter (n,g,p) {
		Experience = e;
		Statics = s;
		w.setweapon();
	}
	void display() {
		cout << "\n-------------------------------------------Warrior---------------------------------\n";
		HumanCharacter::display();
		cout << "\nExperience    : \t" << Experience;
		cout << "\nStatics       : \t" << Statics;
		w.display();
	}
	~Warrior() {

	}

private:
	string Experience;
	float Statics;
	HumanWeapon w;
};

class Mage : public ElfCharacter
{
public:
	Mage(string e,float s, string n, string g, string tt):ElfCharacter(n, g, tt) {
		Experience = e;
		Statics = s;
		w.setweapon();
	}
	void display() {
		cout << "\n-------------------------------------------Mage---------------------------------\n";
		ElfCharacter::display();
		cout << "\nExperience    : \t" << Experience;
		cout << "\nStatics       : \t" << Statics;
		w. display();
	}
	~Mage() {

	}

private:
	string Experience;
	float Statics;
	ElfWeapon w;
};

int main() {
	cout << "Registring Warrior-1:\n";
	Warrior W1("Higly-Experienced",4.0, "ALi", "Male", 399);
	cout << "\nRegistring Mage-1:\n";
	Mage M1("Higly-Experienced", 4.0, "Madara", "Male", "Wind-Style");
	cout << "\nRegistring Warrior-2:\n";
	Warrior W2("Higly-Experienced", 3.2, "Razia", "FeMale", 281);
	cout << "\nRegistring Mage-2:\n";
	Mage M2("UnExperienced", 1.1, "Sakura", "Fe-Male", "Water-Style");
	W1.display();
	W2.display();
	M1.display();
	M2.display();
	return 0;
}