#include<iostream>                                     //L23-0787(Abdul-Rehman Naseer)
using namespace std;

class DynamicMatrix
{
private:
	int** Matrix;
	int rows;
	int cols;
	void initializeMatrix() {
		Matrix = new int* [rows];
		for (int i = 0; i < rows; i++)
		{
			Matrix[i] = new int[cols];
		}
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				Matrix[i][j] = 0;
			}
		}
	}

public:
	DynamicMatrix(int  rows1, int  cols1) {
		rows = rows1;
		cols = cols1;
		initializeMatrix();
	}
	void setValue(int row2, int col2, int value) {
		Matrix[row2][col2] = value;
	}
	int getValue(int row2, int col2) {
		return Matrix[row2][col2];
	}
	void display() {
		cout << "\n\nMatrix : \n";
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				cout << Matrix[i][j] << " ";
			}
			cout << endl;
		}
		cout << "\n\n";
	}
	void resize(int newRows, int newCols) {
		int** newMatrix = new int* [newRows];
		for (int i = 0; i < newRows; i++) {
			newMatrix[i] = new int[newCols]();
		}

		for (int i = 0; i < newRows && i < rows; i++) {
			for (int j = 0; j < newCols && j < cols; j++) {
				newMatrix[i][j] = Matrix[i][j];
			}
		}

		for (int i = 0; i < rows; i++) {
			delete[] Matrix[i];
			Matrix[i] = nullptr;
		}
		delete[] Matrix;
		Matrix = newMatrix;
		rows = newRows;
		cols = newCols;
	}


	~DynamicMatrix() {
		for (int i = 0; i < rows; i++)
		{
			delete[] Matrix[i];
			Matrix[i] = nullptr;
		}
		delete[] Matrix;
	}
};






int main() {
	int Rows = 0, Cols = 0;
	cout << "Please Enter the Number of Rows of Matrix : \t";
	cin >> Rows;
	cout << "Please Enter the Number of Columns of Matrix : \t";
	cin >> Cols;
	DynamicMatrix Obj1(Rows, Cols);
	Obj1.display();

	int Uchiha = 0;    //Signature
	do {
		cout << "Please Enter the Row to set Value : \t";
		cin >> Rows;
		cout << "Please Enter the Columns to set Value : \t";
		cin >> Cols;
		int Value = 0;
		cout << "Please Enter the  Value : \t";
		cin >> Value;
		Obj1.setValue(Rows, Cols, Value);
		Obj1.display();
		cout << "Press 1 if You Want to Set the Value again : \t";
		cin >> Uchiha;
	} while (Uchiha == 1);


	cout << "Please Enter the Number of Rows of Matrix to Resize : \t";
	cin >> Rows;
	cout << "Please Enter the Number of Columns of Matrix to Resize : \t";
	cin >> Cols;
	Obj1.resize(Rows, Cols);
	Obj1.display();



	return 0;
}