#include <iostream>
//L23-0787         ABDUL-REHMAN NASEER
using namespace  std;


//Declairing Functions
void printmanue();
void DisplaySS(int** SS, int rows, int cols);
void Displaysum(int** SS, int r, int cols);
bool detectduplicate(int** arr, int cols, int i, int j, int& k);
void removeit(int** arr, int i, int k, int& cols);
void removeduplicates(int** arr,int rows,int* cols);
void replaceWord(char** arr, const char* word, const char* rep, int PR1, int PC1, char dir);
bool searchWord(char** arr, int rows, int cols, const char* word, int& PR1, int& PC1, char& dir, int& PR2, int& PC2);

int main() {
A: {
	printmanue();
	int Uchiha;       //signature
	cout << "\t\t\t\t1) Exercise-1\n";
	cout << "\t\t\t\t2) Exercise-2\n";
	cout << "\t\t\t\t3) Exercise-3\n";
	cout << "\nPlease Enter the Code Number to Run the Program  : \t";
	cin >> Uchiha;

	if (Uchiha == 1)
	{
		printmanue();
		cout << "\t\t\t\t1) Exercise-1\n";
		cout << "\t\t\t\t Spread Sheet \n";
		cout << "Enter the Number of Rows : \t";
		int rows;
		cin >> rows;
		cout << "Enter the Number of Coloumns: \t";
		int cols;
		cin >> cols;
		int** SS = new int* [rows];                                      //SS = SpreadSheet
		for (int i = 0; i < rows; i++)
		{
			SS[i] = new int[cols];
		}
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				SS[i][j] = 0;
			}
		}
		cout << "\n\nYour SpreadSheat : \n";
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				cout << SS[i][j] <<" ";
			}
			cout << endl;
		}
		cout << "\nEnter the Values : \n";
		for (int i = 0; i < rows; i++)
		{
			for (int j = 0; j < cols; j++)
			{
				cout << "SpreadSheat[" << i << "][" << j << "] : \t";
				cin >> SS[i][j];
				DisplaySS(SS, rows, cols);
			}
		}
		for (int i = 0; i < rows; i++)
		{
			cout << "The Sum of Values in Row[" << i << "] is : \t";
			Displaysum(SS, i, cols);
		}

		for (int i = 0; i < rows; i++)
		{
			delete[] SS[i];
			SS[i] = nullptr;
		}
		delete[] SS;
		SS = nullptr;
	}
	else if (Uchiha == 2)
	{
		printmanue();
		cout << "\t\t\t\t1) Exercise-2\n";
		cout << "Enter the Number of Rows: \t";
		int rows;
		cin >> rows;

		int** arr = new int* [rows];     
		int* cols = new int[rows];      

		for (int i = 0; i < rows; i++) {
			cout << "Enter the Number of Columns for Row " << i + 1 << ": \t";
			cin >> cols[i];             
			arr[i] = new int[cols[i]];  
		}

		cout << "\nEnter the Values:\n";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols[i]; j++) {
				cout << "2D-Array[" << i << "][" << j << "] : \t";
				cin >> arr[i][j];
			}
		}
		cout << "2D-Array : \n";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols[i]; j++) {
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
		removeduplicates(arr, rows, cols);

		cout << "After Removing Duplicates:\n";
		cout << "Number of Rows : \t" << rows << endl;
		for (int i = 0; i < rows; i++) {
			cout << "Row " << i + 1 << " (Columns : " << cols[i] << ") ";
			cout << endl;
		}
		cout << "2D-Array : \n";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols[i]; j++) {
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
		for (int i = 0; i < rows; i++) {
			delete[] arr[i];
		}
		delete[] arr;
		delete[] cols;
	}
	else if (Uchiha == 3)
	{
		printmanue();
		cout << "\t\t\t\t3) Exercise-3\n";
		int rows, cols;
		cout << "Enter the Number of Rows : \t";
		cin >> rows;
		cout << "Enter the Number of Columns : \t";
		cin >> cols;

		char** arr = new char* [rows];
		for (int i = 0; i < rows; i++) {
			arr[i] = new char[cols];
		}

		cout << "\nEnter the characters for the 2D array (1-by-1) : \n";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				cin >> arr[i][j];
			}
		}

		cout << "\nOriginal 2D Array :\n";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
		cout << endl;
		char word[100];
		cout << "\nEnter the Word to Search For : \t";
		cin >> word;

		int wordLen = 0;                       //Length of the Word to search
		while (word[wordLen] != '\0') {
			wordLen++;
		}

		int PR1, PC1;      //Point Row & Columns
		int PR2, PC2;
		char dir;

		if (searchWord(arr, rows, cols, word, PR1, PC1, dir, PR2, PC2)) {
			cout << "\nWord Found at Position (" << PR1 << ", " << PC1 << ")  to (" << PR2 << ", " << PC2 << ") ";
			if (dir == 'H') {
				cout << "Horizontally.\n";
			}
			else if (dir == 'V') {
				cout << "Vertically.\n";
			}

			char rep[25];
		B: {
			cout << "\nEnter the rep Word of the Same Length: ";
			cin >> rep;

			int repLen = 0;                         //Replacement Word's Length
			while (rep[repLen] != '\0') {
				repLen++;
			}

			if (repLen == wordLen) {
				replaceWord(arr, word, rep, PR1, PC1, dir);

				cout << "\n2D-Array after Replacing the Word : \n";
				for (int i = 0; i < rows; i++) {
					for (int j = 0; j < cols; j++) {
						cout << arr[i][j] << " ";
					}
					cout << endl;
				}
			}
			else {
				cout << "\nReplaced Word Must be of the Same Length ! \n";
				goto B;
			}
			}
		}
		else {
			cout << "\nWord not found.\n";
		}

		for (int i = 0; i < rows; i++) {
			delete[] arr[i];
		}
		delete[] arr;


	}
	else
	{
		cout << "\x1b[32m" << "\nPlease Enter the Right Choice!\n" << "\x1b[37m";
		goto A;
	}

	int RR;
	cout << "\x1b[34m" << "Please Enter 1 if you want to Re-Run the Program : \t";
	cin >> RR;
	cout << "\x1b[37m";
	if (RR == 1)
	{
		goto A;
	}
	else {
		return 0;
	}
	return 0;
	}
}






//Functions

void printmanue() {
	system("cls");
	cout << "\x1b[33m";
	cout << "\t\t\t\t======================\n";
	cout << "\t\t\t\t=  OOP LAB-BCS-3A1   =\n";
	cout << "\t\t\t\t=     LABWORK-3      =\n";
	cout << "\t\t\t\t=     L23 -0787      =\n";
	cout << "\t\t\t\t======================\n";
	cout << "=====================================================================================================\n";
	cout << "\x1b[37m";
}


void DisplaySS(int** SS, int rows, int cols) {
	printmanue();
	cout << "\t\t\t\t1) Exercise-1\n";
	cout << "\t\t\t\t Spread Sheet \n";
	cout << "Enter the Number of Rows : \t";
	cout << rows << endl;
	cout << "Enter the Number of Coloumns: \t";
	cout << cols << endl;
	cout << "\nYour SpreadSheat : \n";
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			cout << SS[i][j] << " ";
		}
		cout << endl;
	}
}

void Displaysum(int** SS, int r, int cols) {
	int sum = 0;
		for (int j = 0; j < cols; j++)
		{
			sum += SS[r][j];
		}
		cout << sum << endl;
}

bool detectduplicate(int** arr, int cols, int i, int j, int& k) {
	for (k = 0; k < j; k++) {  
		if (arr[i][k] == arr[i][j]) {
			return true;
		}
	}
	return false;
}

void removeit(int** arr, int i, int k, int& cols) {
	int* newarr = new int[cols - 1];
	for (int j = 0, m = 0; j < cols; j++) {
		if (j != k) {
			newarr[m++] = arr[i][j];
		}
	}
	delete[] arr[i];
	arr[i] = newarr;
	cols--;
}

void removeduplicates(int** arr, int rows, int* cols) {
	bool check = false;
	int k = 0;
	for (int i = 0; i < rows; i++) {
		int j = 0;
		while (j < cols[i]) {
			check = detectduplicate(arr, cols[i], i, j, k);
			if (check) {
				removeit(arr, i, k, cols[i]);
			}
			else {
				j++;  
			}
		}
	}
}

void replaceWord(char** arr, const char* word, const char* rep, int PR1, int PC1, char dir) {
	int wordLen = 0;
	while (word[wordLen] != '\0') {
		wordLen++;
	}

	if (dir == 'H') {
		for (int i = 0; i < wordLen; i++) {
			arr[PR1][PC1 + i] = rep[i];
		}
	}
	else if (dir == 'V') {
		for (int i = 0; i < wordLen; i++) {
			arr[PR1 + i][PC1] = rep[i];
		}
	}
}

bool searchWord(char** arr, int rows, int cols, const char* word, int& PR1, int& PC1, char& dir, int& PR2, int& PC2) {
	int wordLen = 0;
	while (word[wordLen] != '\0') {
		wordLen++;
	}

	for (int i = 0; i < rows; i++) {
		for (int j = 0; j <= cols - wordLen; j++) {
			bool match = true;
			for (int k = 0; k < wordLen; k++) {
				if (arr[i][j + k] != word[k]) {
					match = false;
					break;
				}
			}
			if (match) {
				PR1 = i;
				PC1 = j;
				dir = 'H';
				PR2 = i;
				PC2 = j + wordLen - 1;  // Storing the last matching point in the column
				return true;
			}
		}
	}

	for (int j = 0; j < cols; j++) {
		for (int i = 0; i <= rows - wordLen; i++) {
			bool match = true;
			for (int k = 0; k < wordLen; k++) {
				if (arr[i + k][j] != word[k]) {
					match = false;
					break;
				}
			}
			if (match) {
				PR1 = i;
				PC1 = j;
				dir = 'V';
				PR2 = i + wordLen - 1;  // Storing the last matching point in the row
				PC2 = j;
				return true;
			}
		}
	}

	return false;
}
